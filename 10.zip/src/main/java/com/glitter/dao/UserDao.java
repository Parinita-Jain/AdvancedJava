package com.glitter.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.glitter.util.DBConnect;

public class UserDao {
	Connection con = DBConnect.getConnection();
	
	public boolean addUser(String email, String password) {
		String sql = "insert into user(email,password) values(?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, password);
			
			int i = ps.executeUpdate();
			if(i>0) {
				return true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
}
