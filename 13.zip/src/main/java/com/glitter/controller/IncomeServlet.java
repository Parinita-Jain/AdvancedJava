package com.glitter.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.glitter.dao.IncomeDao;
import com.glitter.model.Income;
import com.glitter.model.User;

@WebServlet("/IncomeServlet")
public class IncomeServlet extends HttpServlet {
	Income inc = new Income();
	IncomeDao incd = new IncomeDao();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		
		User user = (User) session.getAttribute("user");
		
		String action = req.getParameter("action");
		
		if(action!=null && action.equals("delete")) {
			int id = Integer.parseInt(req.getParameter("id"));
			
			boolean b = incd.deleteIncome(id);
			
			if(b) {
				resp.sendRedirect("IncomeServlet");
			}
		}
		else if(action!=null && action.equals("edit")) {
			int id = Integer.parseInt(req.getParameter("id"));
			
			Income inc = incd.getIncome(id);
			
			session.setAttribute("inc", inc);
			
			resp.sendRedirect("updateincome.jsp");
		}
		else {
		
			List<Income> incList = incd.getIncomeList(user.getId());
			session.setAttribute("incList", incList);
			resp.sendRedirect("incomelist.jsp");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		
		User user = (User)session.getAttribute("user");		
		
		Double income = Double.parseDouble(request.getParameter("incomeamount"));
		String incomeType = request.getParameter("incometype");
		String description = request.getParameter("description");
		int userId = Integer.parseInt(request.getParameter("userid"));
		
		if(action!=null && action.equals("addincome")) {
			inc.setIncome(income);
			inc.setIncomeType(incomeType);
			inc.setDescription(description);
			inc.setUserId(userId);
		
			boolean b = new IncomeDao().addIncome(inc);
			if(b) {
				response.sendRedirect("index.jsp");
			}
			else {
				response.sendRedirect("addincome.jsp");
			}
		}
		else if(action!=null & action.equals("updateincome")) {
			inc.setIncome(income);
			inc.setIncomeType(incomeType);
			inc.setDescription(description);
			inc.setUserId(userId);
			
			int id = Integer.parseInt(request.getParameter("id"));
			inc.setId(id);
		
			boolean b = new IncomeDao().updateIncome(inc);
			if(b) {
				response.sendRedirect("IncomeServlet");
			}
		}
	}

}
