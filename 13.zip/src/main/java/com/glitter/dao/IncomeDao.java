package com.glitter.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.glitter.model.Income;
import com.glitter.model.User;
import com.glitter.util.DBConnect;

public class IncomeDao {
	
	Connection con = DBConnect.getConnection();

	public boolean addIncome(Income inc) {
		String sql = "insert into income(income,income_type,description,user_id) values(?,?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, inc.getIncome());
			ps.setString(2, inc.getIncomeType());
			ps.setString(3, inc.getDescription());
			ps.setInt(4, inc.getUserId());
			
			int i = ps.executeUpdate();
			
			if(i>0) {
				return true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<Income> getIncomeList(int uid){
		List<Income> incList = new ArrayList<Income>();
		
		String sql = "select * from income where user_id=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, uid);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Income inc = new Income();
				inc.setId(rs.getInt("id"));
				inc.setIncome(rs.getDouble("income"));
				inc.setIncomeType(rs.getString("income_type"));
				inc.setIncomeDate(rs.getDate("income_date").toString());
				inc.setDescription(rs.getString("description"));
				inc.setUserId(rs.getInt("user_id"));
				
				incList.add(inc);
			}
			
			return incList;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public double getTotalIncome(User user) {
		String sql = "select sum(income) as totalincome from income where user_id=?";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, user.getId());
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				return rs.getDouble("totalincome");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public boolean deleteIncome(int id) {
		String sql = "delete from income where id=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			
			int i = ps.executeUpdate();
			
			if(i>0) {
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public Income getIncome(int id) {
		String sql = "select * from income where id=?";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				Income inc = new Income();
				inc.setId(rs.getInt("id"));
				inc.setIncome(rs.getDouble("income"));
				inc.setIncomeType(rs.getString("income_type"));
				inc.setIncomeDate(rs.getDate("income_date").toString());
				inc.setDescription(rs.getString("description"));
				inc.setUserId(rs.getInt("user_id"));
				
				return inc;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public boolean updateIncome(Income inc) {
		String sql = "update income set income=?, income_type=?, description=?, user_id=? where id=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, inc.getIncome());
			ps.setString(2, inc.getIncomeType());
			ps.setString(3, inc.getDescription());
			ps.setInt(4, inc.getUserId());
			ps.setInt(5, inc.getId());
			
			int i = ps.executeUpdate();
			
			if(i>0) {
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
}
