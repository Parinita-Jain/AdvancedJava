package com.itvedant;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookiesServlet
 */
@WebServlet("/cookies")
public class CookiesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CookiesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		response.setContentType("text/html");
		
		//read all the cookies in the request from the client
		Cookie[] allCookies = request.getCookies();
		PrintWriter out = response.getWriter();
		if(allCookies!=null) {
			for(int i=0;i<allCookies.length;i++) {
				if(allCookies[i].getValue() == name) {
					out.println("Welcome Back, " + name);
					break;
				}
				else {
					out.println("Hello, " + name);
					Cookie ck = new Cookie("username", name);
					response.addCookie(ck);
				}
			}
		}
		else {		
			//creating a new cookie
			Cookie ck = new Cookie("username", name);
		
			//add the cookie in the response
			response.addCookie(ck);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
