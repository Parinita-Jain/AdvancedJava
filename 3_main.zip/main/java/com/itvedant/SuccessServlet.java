package com.itvedant;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SuccessServlet
 */
@WebServlet("/success")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SuccessServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		
		RequestDispatcher rd = request.getRequestDispatcher("header");
		rd.include(request, response);
		
		PrintWriter out = response.getWriter();
		out.println("<br/>");
		out.println("<br/>");
		out.println("<h3 style='color:green'>Welcome, " + username +"</h3>");
		
		//String color = getInitParameter("color");
		//out.println(color);
		
		String oper = (String) request.getAttribute("oper");
		
		out.println("<form>");
		out.println("Select an operation: ");
		String[] options = oper.split(",");
		out.println("<select name='operation'>");
		for(String o : options) {
			out.println("<option>" + o + "</option>");
		}
		out.println("</select>");
		out.println("<input type='submit' value='OK'/>");
		out.println("</form>");
		
		//Getting the reference of the ServletContext object
		ServletContext context = getServletContext();
				
		//Get the parameter created inside the ServletContext object
		String programmer = context.getInitParameter("programmerName");
		
		out.println("<small>" + programmer + "</small>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
