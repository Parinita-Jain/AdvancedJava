package com.itvedant;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HeaderServlet
 */
public class HeaderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HeaderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		String color = getInitParameter("color");
		String bgcolor = getInitParameter("bgcolor");	
		
		
		out.println("<div style='width:100%; "
					+ "padding:10px; "
					+ "background-color: " + bgcolor + ";" 
					+ "color: " + color +  ";"
					+ "text-align: center;"
					+ "height: 100px;'>");
		out.println("<h1>Glitter Computer Pvt. Ltd.</h1>");
		
		//Getting the reference of the ServletContext object
		ServletContext context = getServletContext();
		
		//Get the parameter created inside the ServletContext object
		String programmer = context.getInitParameter("programmerName");
		
		out.println("<h4>Designed by " + programmer + "</h4>");
		out.println("</div>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
