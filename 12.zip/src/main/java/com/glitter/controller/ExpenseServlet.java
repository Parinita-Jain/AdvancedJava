package com.glitter.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.glitter.dao.ExpenseDao;
import com.glitter.model.Expense;

@WebServlet("/ExpenseServlet")
public class ExpenseServlet extends HttpServlet {	
	Expense exp = new Expense();
	ExpenseDao expd = new ExpenseDao();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		List<Expense> expList = expd.getExpenseList();
		session.setAttribute("expList", expList);
		resp.sendRedirect("expenselist.jsp");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Double expense = Double.parseDouble(request.getParameter("expenseamount"));
		String expenseType = request.getParameter("expensetype");
		String description = request.getParameter("description");
		int userId = Integer.parseInt(request.getParameter("userid"));
		
		exp.setExpense(expense);
		exp.setExpenseType(expenseType);
		exp.setDescription(description);
		exp.setUserId(userId);
		
		boolean b = new ExpenseDao().addExpense(exp);
		if(b) {
			response.sendRedirect("index.jsp");
		}
		else {
			response.sendRedirect("addincome.jsp");
		}
	}

}
