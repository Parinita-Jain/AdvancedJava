package com.glitter.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.glitter.model.Expense;
import com.glitter.model.Income;
import com.glitter.util.DBConnect;

public class ExpenseDao {
	Connection con = DBConnect.getConnection();

	public boolean addExpense(Expense inc) {
		String sql = "insert into expense(expense,expense_type,description,user_id) values(?,?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, inc.getExpense());
			ps.setString(2, inc.getExpenseType());
			ps.setString(3, inc.getDescription());
			ps.setInt(4, inc.getUserId());
			
			int i = ps.executeUpdate();
			
			if(i>0) {
				return true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<Expense> getExpenseList(){
		List<Expense> expList = new ArrayList<Expense>();
		
		String sql = "select * from expense";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Expense exp = new Expense();
				exp.setId(rs.getInt("id"));
				exp.setExpense(rs.getDouble("expense"));
				exp.setExpenseType(rs.getString("expense_type"));
				exp.setExpenseDate(rs.getDate("expense_date").toString());
				exp.setDescription(rs.getString("description"));
				exp.setUserId(rs.getInt("user_id"));
				
				expList.add(exp);
			}
			
			return expList;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	
}
