package com.glitter.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.glitter.dao.UserDao;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password1 = request.getParameter("passwd1");
		String password2 = request.getParameter("passwd2");
		
		if(email!=null && password1.equals(password2)) {
			//insert the user details in the database
			boolean b = new UserDao().addUser(email, password1);
			
			if(b) {
				response.sendRedirect("index.jsp");
			}
			else {
				request.setAttribute("errorMsg", 
						"User Already Exists!");
				request.getRequestDispatcher("adduser.jsp").include(request, response);
			}
		}
		else {
			//display the error message
			request.setAttribute("errorMsg", 
					"Password and Confirm Password Does Not Match!");
			request.getRequestDispatcher("adduser.jsp").include(request, response);
		}
	}
}
