package com.glitter.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.glitter.dao.ExpenseDao;
import com.glitter.model.Expense;

@WebServlet("/ExpenseServlet")
public class ExpenseServlet extends HttpServlet {	
	Expense exp = new Expense();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Double expense = Double.parseDouble(request.getParameter("expenseamount"));
		String expenseType = request.getParameter("expensetype");
		String description = request.getParameter("description");
		int userId = Integer.parseInt(request.getParameter("userid"));
		
		exp.setExpense(expense);
		exp.setExpenseType(expenseType);
		exp.setDescription(description);
		exp.setUserId(userId);
		
		boolean b = new ExpenseDao().addExpense(exp);
		if(b) {
			response.sendRedirect("index.jsp");
		}
		else {
			response.sendRedirect("addincome.jsp");
		}
	}

}
